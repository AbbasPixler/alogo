const express = require("express")
const Languages = require("./../model/model.languages")
const auth = require("../../middleware/auth")
const router = express.Router()

router.post("/create", auth, async(req, res) => {

  try{
    if(req.body.language.language.length < 1 || req.body.language.initials.length < 1){
      return res.send({
        status: false,
        message: "Please provide all neccessary information!",
        data: null
      })
    }
    const alreadyName = await Languages.find({language: req.body.language.language})
    const alreadyInitials = await Languages.find({initials: req.body.language.initials})
  
    if(alreadyName.length > 0 || alreadyInitials.length > 0){
      return res.send({
        status: false,
        message: "Language oe Initials already exist!",
        data: null
      })
    }
    const language = new Languages(req.body.language)
    await language.save()
  
    return res.json({
      status: true,
      message: "Language created successfully !",
      data: language
    })  
  }catch(err){
    return res.send({
      status: false,
      message: err.message,
      data: null
    })
  }

  
})

router.post("/fetchAll", auth, async(req, res) => {
  try{
    const languages = await Languages.find()
    if(languages.length < 1){
      return res.json({
        status: false,
        message: "No Languages found!",
        data: null
      })
    }
    return res.json({
      status: true,
      message: "Languages fetched successfully!",
      data: languages
    })
  }catch(err){
    return res.json({
      status: false,
      message: err.message,
      data: null
    })
  }
})

module.exports = router
